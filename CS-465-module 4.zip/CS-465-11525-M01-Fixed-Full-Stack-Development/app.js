const express = require('express');
const path = require('path');
const hbs = require('hbs');
require('./app_server/models/db');

const indexRouter = require('./app_server/routes/index');

const app = express();
const port = process.env.PORT || 3000;

app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');
hbs.registerPartials(path.join(__dirname, 'app_server', 'views', 'partials'));

app.use(express.static(path.join(__dirname, 'public')));
app.use('/', indexRouter);

app.listen(port, () => {
  console.log(`Travlr Getaways running at http://localhost:${port}`);
});

module.exports = app;
