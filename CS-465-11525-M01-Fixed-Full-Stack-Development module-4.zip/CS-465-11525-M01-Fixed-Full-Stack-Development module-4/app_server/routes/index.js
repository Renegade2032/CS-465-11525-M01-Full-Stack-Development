const express = require('express');
const router = express.Router();
const ctrlMain = require('../controllers/main');

router.get('/', ctrlMain.index);

router.get('/travel', (req, res) => {
    const tripData = require('../data/trips.json');

    res.render('travel', {
        title: 'Travel - Travlr Getaways',
        travel: true,
        tripData: tripData
    });
});

router.get('/rooms', ctrlMain.rooms);
router.get('/meals', ctrlMain.meals);
router.get('/news', ctrlMain.news);
router.get('/about', ctrlMain.about);
router.get('/contact', ctrlMain.contact);

module.exports = router;