const trips = require('../data/trips');


const renderPage = (view, title, activePage) => (req, res) => {
  const data = { title };
  data[activePage] = true;
  res.render(view, data);
};

module.exports = {
  index: renderPage('index', 'Travlr Getaways', 'home'),
    travel: (req, res) => {
        const tripData = require('../data/trips.json');

        res.render('travel', {
            title: 'Travel - Travlr Getaways',
            travel: true,
            tripData: tripData
        });
    },
  rooms: renderPage('rooms', 'Rooms - Travlr Getaways', 'rooms'),
  meals: renderPage('meals', 'Meals - Travlr Getaways', 'meals'),
  news: renderPage('news', 'News - Travlr Getaways', 'news'),
  about: renderPage('about', 'About - Travlr Getaways', 'about'),
  contact: renderPage('contact', 'Contact - Travlr Getaways', 'contact')
};
