const mongoose = require('./app_server/models/db');
const fs = require('fs');

const Trip = mongoose.model('trips');

const trips = JSON.parse(
    fs.readFileSync('./app_server/data/trips.json', 'utf8')
);

Trip.deleteMany({})
    .then(() => Trip.insertMany(trips))
    .then(() => {
        console.log('Trips loaded successfully');
        process.exit();
    })
    .catch(err => {
        console.log(err);
        process.exit();
    });