const renderPage = (view, title, activePage) => (req, res) => {
  const data = { title };
  data[activePage] = true;
  res.render(view, data);
};

module.exports = {
  index: renderPage('index', 'Travlr Getaways', 'home'),
  travel: renderPage('travel', 'Travel - Travlr Getaways', 'travel'),
  rooms: renderPage('rooms', 'Rooms - Travlr Getaways', 'rooms'),
  meals: renderPage('meals', 'Meals - Travlr Getaways', 'meals'),
  news: renderPage('news', 'News - Travlr Getaways', 'news'),
  about: renderPage('about', 'About - Travlr Getaways', 'about'),
  contact: renderPage('contact', 'Contact - Travlr Getaways', 'contact')
};
